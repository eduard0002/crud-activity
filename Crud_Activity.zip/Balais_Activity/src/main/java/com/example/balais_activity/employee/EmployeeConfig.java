package com.example.balais_activity.employee;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.util.List;

@Configuration
public class EmployeeConfig {

    @Bean
    CommandLineRunner commandLineRunner(
            EmployeeRepository repository){
        return args -> {
            Employee eduard = new Employee(
                    "Eduard Lyndon",
                    "Balais",
                    "Rociento",
                    "Jr.",
                    LocalDate.of(1996, 12, 2)
            );

            Employee kristele = new Employee(
                    "Kristele",
                    "Balais",
                    "Rociento",
                    "",
                    LocalDate.of(2000, 4, 29)
            );

            repository.saveAll(
                    List.of(eduard , kristele)
            );

        };
    }

}
