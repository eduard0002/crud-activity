package com.example.balais_activity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class BalaisActivityApplication {

    public static void main(String[] args) {
        SpringApplication.run(BalaisActivityApplication.class, args);
    }

}
