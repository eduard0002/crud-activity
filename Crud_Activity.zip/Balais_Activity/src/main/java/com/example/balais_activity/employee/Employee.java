package com.example.balais_activity.employee;

import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.Period;

@Entity
@Table
public class Employee {
    @Id
    @SequenceGenerator(
            name = "employee_sequence",
            sequenceName = "employee_sequence",
            allocationSize = 1
    )

    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "employee_sequence"
    )
    private Long id;
    private String first_name;
    private String last_name;
    private String middle_name;
    private String extension_name;
    private LocalDate birthday;

    @Transient
    private Integer age;

    public Employee() {
    }

    public Employee(Long id,
                    String first_name,
                    String last_name,
                    String middle_name,
                    String extension_name,
                    LocalDate birthday) {
        this.id = id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.middle_name = middle_name;
        this.extension_name = extension_name;
        this.birthday = birthday;

    }

    public Employee(String first_name,
                    String last_name,
                    String middle_name,
                    String extension_name,
                    LocalDate birthday) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.middle_name = middle_name;
        this.extension_name = extension_name;
        this.birthday = birthday;

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getMiddle_name() {
        return middle_name;
    }

    public void setMiddle_name(String middle_name) {
        this.middle_name = middle_name;
    }

    public String getExtension_name() {
        return extension_name;
    }

    public void setExtension_name(String extension_name) {
        this.extension_name = extension_name;
    }

    public LocalDate getBirthday() {
        return birthday;
    }

    public void setBirthday(LocalDate birthday) {
        this.birthday = birthday;
    }

    public Integer getAge() {
        return Period.between(this.birthday, LocalDate.now()).getYears();
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", first_name='" + first_name + '\'' +
                ", last_name='" + last_name + '\'' +
                ", middle_name='" + middle_name + '\'' +
                ", extension_name='" + extension_name + '\'' +
                ", birthday=" + birthday +
                ", age=" + age +
                '}';
    }
}
